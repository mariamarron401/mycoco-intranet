=== MyCoco · Chat de acompañamiento ===
Contributors: MyCoco
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

== Descripción ==

Integra en la web el chat de acompañamiento y recursos de MyCoco / Positiv@s Pero Realistas.

El chat se carga en un iframe de otro origen: no comparte cookies ni estilos con la web,
no escribe nada en el navegador de la visitante y no interfiere con el aviso de cookies.

IMPORTANTE — El chat está en fase de piloto interno. Deja la visibilidad en
"solo personas con sesión abierta" hasta que estén cerradas las validaciones clínica,
psicooncológica, jurídica y de protección de datos.

== Instalación ==

1. WordPress → Plugins → Añadir nuevo → Subir plugin → elige el archivo .zip
2. Activar
3. Ajustes → Chat MyCoco → revisa quién lo ve y guarda

== Uso ==

- Botón flotante: se activa desde Ajustes → Chat MyCoco.
- Página dedicada: pega el shortcode [mycoco_chat] en cualquier página.
  Con altura propia: [mycoco_chat altura="760"]

== Registro de cambios ==

= 1.0.0 =
* Versión inicial: botón flotante, shortcode, control de visibilidad y exclusión de páginas.
