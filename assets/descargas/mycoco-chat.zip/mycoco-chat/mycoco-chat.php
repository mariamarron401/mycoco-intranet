<?php
/**
 * Plugin Name:       MyCoco · Chat de acompañamiento
 * Plugin URI:        https://mycoco-intranet.pages.dev/secciones/chatbot-acompanamiento-piloto.html
 * Description:       Integra el chat de acompañamiento y recursos en la web. Durante el piloto se muestra solo a las personas conectadas al panel de WordPress, para poder probarlo en la web real sin abrirlo a las visitantes.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Sara Gascón Durán · MyCoco
 * License:           GPL-2.0-or-later
 * Text Domain:       mycoco-chat
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Sin acceso directo.
}

const MYCOCO_CHAT_VERSION = '1.0.0';
const MYCOCO_CHAT_OPCION  = 'mycoco_chat_opciones';

/**
 * Valores por defecto. Deliberadamente conservadores: el piloto arranca visible
 * solo para quien tenga sesión abierta en WordPress.
 */
function mycoco_chat_defaults() {
	return array(
		'activo'     => 1,
		'origen'     => 'https://chat-acompanamiento.maria-marron.workers.dev',
		'visibilidad'=> 'conectados',   // conectados | administradores | todos
		'texto'      => 'Hablemos',
		'posicion'   => 'derecha',
		'excluir'    => '',             // slugs o IDs separados por comas
	);
}

function mycoco_chat_opciones() {
	return wp_parse_args( get_option( MYCOCO_CHAT_OPCION, array() ), mycoco_chat_defaults() );
}

/**
 * ¿Debe cargarse el chat en esta petición?
 */
function mycoco_chat_debe_mostrarse( $o ) {
	if ( empty( $o['activo'] ) || empty( $o['origen'] ) ) {
		return false;
	}
	if ( is_admin() || is_feed() || is_embed() || is_404() ) {
		return false;
	}

	switch ( $o['visibilidad'] ) {
		case 'administradores':
			if ( ! current_user_can( 'manage_options' ) ) {
				return false;
			}
			break;
		case 'conectados':
			if ( ! is_user_logged_in() ) {
				return false;
			}
			break;
		case 'todos':
		default:
			break;
	}

	// Páginas excluidas por slug o por ID.
	$excluir = array_filter( array_map( 'trim', explode( ',', (string) $o['excluir'] ) ) );
	if ( $excluir ) {
		$id   = get_queried_object_id();
		$slug = is_singular() ? get_post_field( 'post_name', $id ) : '';
		foreach ( $excluir as $e ) {
			if ( ( is_numeric( $e ) && (int) $e === (int) $id ) || ( $slug && $e === $slug ) ) {
				return false;
			}
		}
	}

	return true;
}

/**
 * Carga el widget en el pie. El chat vive en un iframe de otro origen: no
 * comparte cookies ni estilos con la web, y no escribe nada en el navegador.
 */
function mycoco_chat_encolar() {
	$o = mycoco_chat_opciones();
	if ( ! mycoco_chat_debe_mostrarse( $o ) ) {
		return;
	}

	$src = esc_url( trailingslashit( $o['origen'] ) . 'widget.js' );
	wp_enqueue_script( 'mycoco-chat', $src, array(), MYCOCO_CHAT_VERSION, true );

	// El widget lee su configuración de los atributos data- de su propia etiqueta.
	add_filter(
		'script_loader_tag',
		function ( $tag, $handle ) use ( $o ) {
			if ( 'mycoco-chat' !== $handle ) {
				return $tag;
			}
			$attrs = sprintf(
				' data-texto="%s" data-posicion="%s"',
				esc_attr( $o['texto'] ),
				'izquierda' === $o['posicion'] ? 'izquierda' : 'derecha'
			);
			return str_replace( ' src=', $attrs . ' src=', $tag );
		},
		10,
		2
	);
}
add_action( 'wp_enqueue_scripts', 'mycoco_chat_encolar' );

/**
 * Shortcode para incrustarlo dentro de una página concreta, a tamaño completo:
 *   [mycoco_chat]            o    [mycoco_chat altura="700"]
 * Útil para una página "Acompañamiento" sin el botón flotante.
 */
function mycoco_chat_shortcode( $atts ) {
	$o = mycoco_chat_opciones();
	if ( empty( $o['origen'] ) ) {
		return '';
	}
	$a = shortcode_atts( array( 'altura' => '680' ), $atts, 'mycoco_chat' );

	return sprintf(
		'<div class="mycoco-chat-inline" style="max-width:720px;margin:0 auto">
			<iframe src="%s" title="%s" loading="lazy"
				style="width:100%%;height:%dpx;border:0;border-radius:18px;background:#EED8C1"></iframe>
		</div>',
		esc_url( trailingslashit( $o['origen'] ) ),
		esc_attr__( 'Chat de acompañamiento', 'mycoco-chat' ),
		max( 400, (int) $a['altura'] )
	);
}
add_shortcode( 'mycoco_chat', 'mycoco_chat_shortcode' );

/* ---------------------------------------------------------------- ajustes -- */

function mycoco_chat_menu() {
	add_options_page(
		__( 'Chat de acompañamiento', 'mycoco-chat' ),
		__( 'Chat MyCoco', 'mycoco-chat' ),
		'manage_options',
		'mycoco-chat',
		'mycoco_chat_pagina'
	);
}
add_action( 'admin_menu', 'mycoco_chat_menu' );

function mycoco_chat_registrar() {
	register_setting(
		'mycoco_chat',
		MYCOCO_CHAT_OPCION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'mycoco_chat_sanear',
			'default'           => mycoco_chat_defaults(),
		)
	);
}
add_action( 'admin_init', 'mycoco_chat_registrar' );

function mycoco_chat_sanear( $in ) {
	$in = is_array( $in ) ? $in : array();
	$d  = mycoco_chat_defaults();
	return array(
		'activo'      => empty( $in['activo'] ) ? 0 : 1,
		'origen'      => isset( $in['origen'] ) ? esc_url_raw( untrailingslashit( trim( $in['origen'] ) ) ) : $d['origen'],
		'visibilidad' => in_array( $in['visibilidad'] ?? '', array( 'todos', 'conectados', 'administradores' ), true )
			? $in['visibilidad'] : $d['visibilidad'],
		'texto'       => sanitize_text_field( $in['texto'] ?? $d['texto'] ),
		'posicion'    => 'izquierda' === ( $in['posicion'] ?? '' ) ? 'izquierda' : 'derecha',
		'excluir'     => sanitize_text_field( $in['excluir'] ?? '' ),
	);
}

function mycoco_chat_pagina() {
	$o = mycoco_chat_opciones();
	$n = MYCOCO_CHAT_OPCION;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Chat de acompañamiento', 'mycoco-chat' ); ?></h1>

		<div class="notice notice-warning inline" style="margin:1em 0;padding:.8em 1em">
			<p style="margin:0"><strong>Piloto interno.</strong> Mientras no estén cerradas las validaciones
			clínica, psicooncológica y de protección de datos, deja la visibilidad en
			<em>solo personas conectadas</em>. Así puedes probarlo en la web real sin que lo vean las visitantes.</p>
		</div>

		<form method="post" action="options.php">
			<?php settings_fields( 'mycoco_chat' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Activar', 'mycoco-chat' ); ?></th>
					<td><label>
						<input type="checkbox" name="<?php echo esc_attr( $n ); ?>[activo]" value="1" <?php checked( $o['activo'] ); ?>>
						<?php esc_html_e( 'Mostrar el botón del chat en la web', 'mycoco-chat' ); ?>
					</label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Quién lo ve', 'mycoco-chat' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $n ); ?>[visibilidad]">
							<option value="administradores" <?php selected( $o['visibilidad'], 'administradores' ); ?>><?php esc_html_e( 'Solo administradoras', 'mycoco-chat' ); ?></option>
							<option value="conectados" <?php selected( $o['visibilidad'], 'conectados' ); ?>><?php esc_html_e( 'Solo personas con sesión abierta (recomendado en el piloto)', 'mycoco-chat' ); ?></option>
							<option value="todos" <?php selected( $o['visibilidad'], 'todos' ); ?>><?php esc_html_e( 'Todo el mundo (solo tras cerrar las validaciones)', 'mycoco-chat' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Texto del botón', 'mycoco-chat' ); ?></th>
					<td><input type="text" class="regular-text" name="<?php echo esc_attr( $n ); ?>[texto]" value="<?php echo esc_attr( $o['texto'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Posición', 'mycoco-chat' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $n ); ?>[posicion]">
							<option value="derecha" <?php selected( $o['posicion'], 'derecha' ); ?>><?php esc_html_e( 'Abajo a la derecha', 'mycoco-chat' ); ?></option>
							<option value="izquierda" <?php selected( $o['posicion'], 'izquierda' ); ?>><?php esc_html_e( 'Abajo a la izquierda', 'mycoco-chat' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'No mostrar en', 'mycoco-chat' ); ?></th>
					<td>
						<input type="text" class="regular-text" name="<?php echo esc_attr( $n ); ?>[excluir]" value="<?php echo esc_attr( $o['excluir'] ); ?>" placeholder="contacto, 42, aviso-legal">
						<p class="description"><?php esc_html_e( 'Slugs o IDs de páginas separados por comas.', 'mycoco-chat' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Dirección del chat', 'mycoco-chat' ); ?></th>
					<td>
						<input type="url" class="large-text code" name="<?php echo esc_attr( $n ); ?>[origen]" value="<?php echo esc_attr( $o['origen'] ); ?>">
						<p class="description"><?php esc_html_e( 'No cambiar salvo que el chat se mueva de dirección.', 'mycoco-chat' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Incrustarlo dentro de una página', 'mycoco-chat' ); ?></h2>
		<p><?php esc_html_e( 'Si además quieres una página dedicada con el chat a tamaño completo, pega este shortcode en ella:', 'mycoco-chat' ); ?></p>
		<p><code>[mycoco_chat]</code> &nbsp; <?php esc_html_e( 'o con altura propia:', 'mycoco-chat' ); ?> &nbsp; <code>[mycoco_chat altura="760"]</code></p>
	</div>
	<?php
}
